const test = require("node:test");
const assert = require("node:assert/strict");
const { loadScripts } = require("./helpers/loadGlobals");

function createFakeChrome() {
  let store = {};
  let failNextSetCalls = 0;
  let badgeText = "";
  let activeTab = null;

  const local = {
    get: (keys) => {
      if (keys === null || keys === undefined) {
        return Promise.resolve({ ...store });
      }
      const list = Array.isArray(keys) ? keys : [keys];
      const result = {};
      for (const key of list) {
        if (key in store) {
          result[key] = store[key];
        }
      }
      return Promise.resolve(result);
    },
    set: (obj) => {
      if (failNextSetCalls > 0) {
        failNextSetCalls--;
        return Promise.reject(
          new Error("Resource::kQuotaBytes quota exceeded")
        );
      }
      Object.assign(store, obj);
      return Promise.resolve();
    },
    remove: (keys) => {
      const list = Array.isArray(keys) ? keys : [keys];
      for (const key of list) {
        delete store[key];
      }
      return Promise.resolve();
    },
    clear: () => {
      store = {};
      return Promise.resolve();
    },
  };

  const noopListener = { addListener: () => {} };

  return {
    chrome: {
      storage: { local },
      action: {
        setBadgeText: ({ text }) => {
          badgeText = text;
          return Promise.resolve();
        },
        setBadgeBackgroundColor: () => Promise.resolve(),
        setTitle: () => Promise.resolve(),
        setPopup: () => Promise.resolve(),
        onClicked: noopListener,
      },
      webRequest: {
        onBeforeRequest: noopListener,
        onHeadersReceived: noopListener,
        onBeforeSendHeaders: noopListener,
        onErrorOccurred: noopListener,
      },
      runtime: {
        onMessage: noopListener,
        onInstalled: noopListener,
        onStartup: noopListener,
        getManifest: () => ({ name: "Detector APIs Extension" }),
        requestUpdateCheck: () => Promise.resolve({ status: "no_update" }),
        reload: () => {},
        id: "test-extension-id",
      },
      alarms: {
        create: () => {},
        onAlarm: noopListener,
      },
      tabs: {
        onUpdated: noopListener,
        onRemoved: noopListener,
        query: () => Promise.resolve(activeTab ? [activeTab] : []),
      },
    },
    dump: () => store,
    failNextSet: (n) => {
      failNextSetCalls = n;
    },
    badgeText: () => badgeText,
    setActiveTab: (tab) => {
      activeTab = tab;
    },
  };
}

function buildBackgroundSandbox() {
  const { chrome, dump, failNextSet, badgeText, setActiveTab } =
    createFakeChrome();
  // TextEncoder is a host global (available in real service workers), not a
  // JS language built-in, so a fresh vm context needs it injected explicitly
  // — same reason `handleResponseBodyCapture`'s byte-size fallback needs it.
  const sandbox = { chrome, importScripts: () => {}, TextEncoder };
  loadScripts(["js/constants.js", "js/utils.js"], { sandbox });
  loadScripts(["js/background.js"], { sandbox });
  return { sandbox, dump, failNextSet, badgeText, setActiveTab };
}

test("getValueHeaderByKey is case-insensitive and returns '' when missing", () => {
  const { sandbox } = buildBackgroundSandbox();
  const headers = [{ name: "Content-Type", value: "application/json" }];
  assert.equal(sandbox.getValueHeaderByKey("content-type", headers), "application/json");
  assert.equal(sandbox.getValueHeaderByKey("missing", headers), "");
});

test("safeStorageSet swallows a quota-exceeded rejection instead of throwing", async () => {
  const { sandbox, dump, failNextSet } = buildBackgroundSandbox();
  failNextSet(1);

  await assert.doesNotReject(sandbox.safeStorageSet({ "some-key": "value" }));

  assert.equal(dump()["some-key"], undefined, "the failed write never landed");
});

test("trackAndEvict doesn't throw even if persisting the updated order fails (regression: a rejected set() used to abort the rest of the listener)", async () => {
  const { sandbox, failNextSet } = buildBackgroundSandbox();
  failNextSet(1);

  await assert.doesNotReject(sandbox.trackAndEvict("req-1"));
});

test("trackAndEvict appends requestIds in the order they're seen", async () => {
  const { sandbox, dump } = buildBackgroundSandbox();

  await sandbox.trackAndEvict("req-1");
  await sandbox.trackAndEvict("req-2");
  await sandbox.trackAndEvict("req-3");

  const order = dump()[sandbox.REQUEST_ORDER_KEY];
  assert.equal(order.length, 3);
  assert.equal(order[0], "req-1");
  assert.equal(order[1], "req-2");
  assert.equal(order[2], "req-3");
});

test("trackAndEvict serializes concurrent calls instead of losing one to a read-modify-write race (regression: two requestIds starting in the same tick used to silently drop one from REQUEST_ORDER_KEY, even though its own data was written fine)", async () => {
  const { sandbox, dump } = buildBackgroundSandbox();

  // Deliberately not awaited individually — both start before either
  // finishes, exercising the exact interleaving that used to lose an update.
  await Promise.all([
    sandbox.trackAndEvict("concurrent-a"),
    sandbox.trackAndEvict("concurrent-b"),
    sandbox.trackAndEvict("concurrent-c"),
  ]);

  const order = dump()[sandbox.REQUEST_ORDER_KEY];
  assert.equal(order.length, 3);
  assert.deepEqual(
    [...order].sort(),
    ["concurrent-a", "concurrent-b", "concurrent-c"]
  );
});

test("clearTabRequests and trackAndEvict share the same lock, so a request tracked mid-clear isn't lost either", async () => {
  const { sandbox, dump } = buildBackgroundSandbox();

  await sandbox.chrome.storage.local.set({
    "old-req-tab-id": 10,
    "old-req-url": "https://a.example.com",
  });
  await sandbox.trackAndEvict("old-req");

  await sandbox.chrome.storage.local.set({ "new-req-tab-id": 20 });
  await Promise.all([
    sandbox.clearTabRequests(10),
    sandbox.trackAndEvict("new-req"),
  ]);

  const order = dump()[sandbox.REQUEST_ORDER_KEY];
  assert.deepEqual([...order].sort(), ["new-req"]);
  assert.equal(dump()["old-req-url"], undefined);
});

test("trackAndEvict evicts the oldest requestId (and all its keys) once MAX_TRACKED_REQUESTS is exceeded", async () => {
  const { sandbox, dump } = buildBackgroundSandbox();
  const max = sandbox.MAX_TRACKED_REQUESTS;

  for (let i = 0; i < max; i++) {
    const requestId = `req-${i}`;
    await sandbox.chrome.storage.local.set({
      [requestId + "-url"]: `https://api.example.com/item-${i}`,
      [requestId + "-curl-detector-apis"]: "curl '...'",
    });
    await sandbox.trackAndEvict(requestId);
  }

  await sandbox.trackAndEvict("req-overflow");

  const state = dump();
  assert.equal(
    state["req-0-curl-detector-apis"],
    undefined,
    "oldest request's curl data should be evicted"
  );
  assert.equal(
    state["req-0-url"],
    undefined,
    "oldest request's url should be evicted"
  );
  assert.equal(state["req-overflow-curl-detector-apis"], undefined);
  const order = state[sandbox.REQUEST_ORDER_KEY];
  assert.equal(order.length, max);
  assert.ok(order.includes("req-overflow"));
  assert.ok(!order.includes("req-0"));
});

test("getMaxTrackedRequests falls back to the MAX_TRACKED_REQUESTS default when nothing is configured, an invalid value is ignored, and a valid override wins", async () => {
  const { sandbox } = buildBackgroundSandbox();

  assert.equal(await sandbox.getMaxTrackedRequests(), sandbox.MAX_TRACKED_REQUESTS);

  await sandbox.chrome.storage.local.set({ [sandbox.MAX_TRACKED_REQUESTS_KEY]: 0 });
  assert.equal(await sandbox.getMaxTrackedRequests(), sandbox.MAX_TRACKED_REQUESTS);

  await sandbox.chrome.storage.local.set({ [sandbox.MAX_TRACKED_REQUESTS_KEY]: 5 });
  assert.equal(await sandbox.getMaxTrackedRequests(), 5);
});

test("trackAndEvict respects a configured MAX_TRACKED_REQUESTS_KEY override, evicting sooner than the 150 default", async () => {
  const { sandbox, dump } = buildBackgroundSandbox();
  await sandbox.chrome.storage.local.set({ [sandbox.MAX_TRACKED_REQUESTS_KEY]: 2 });

  await sandbox.trackAndEvict("req-1");
  await sandbox.trackAndEvict("req-2");
  await sandbox.trackAndEvict("req-3");

  const order = dump()[sandbox.REQUEST_ORDER_KEY];
  assert.equal(order.length, 2);
  assert.equal(order[0], "req-2");
  assert.equal(order[1], "req-3");
});

test("claimPendingBodyMatch is FIFO per url and returns null once drained", () => {
  const { sandbox } = buildBackgroundSandbox();
  sandbox.registerPendingBodyMatch("https://api.example.com/graphql", "req-a");
  sandbox.registerPendingBodyMatch("https://api.example.com/graphql", "req-b");

  assert.equal(sandbox.claimPendingBodyMatch("https://api.example.com/graphql"), "req-a");
  assert.equal(sandbox.claimPendingBodyMatch("https://api.example.com/graphql"), "req-b");
  assert.equal(sandbox.claimPendingBodyMatch("https://api.example.com/graphql"), null);
});

test("untrackPendingBodyMatch removes a queued requestId so it's never claimed", () => {
  const { sandbox } = buildBackgroundSandbox();
  sandbox.registerPendingBodyMatch("https://api.example.com/graphql", "req-a");
  sandbox.registerPendingBodyMatch("https://api.example.com/graphql", "req-b");

  sandbox.untrackPendingBodyMatch("req-a");

  assert.equal(sandbox.claimPendingBodyMatch("https://api.example.com/graphql"), "req-b");
});

test("handleResponseBodyCapture stores the body under the claimed requestId, only when a match was registered", async () => {
  const { sandbox, dump } = buildBackgroundSandbox();

  sandbox.registerPendingBodyMatch("https://api.example.com/data", "req-1");
  await sandbox.handleResponseBodyCapture({
    url: "https://api.example.com/data",
    contentType: "application/json",
    body: '{"ok":true}',
  });

  // this url was never registered as a pending match (e.g. a non-XHR/fetch
  // resource that response-capture.js never hooks), so there's nothing to
  // claim and nothing gets stored — regardless of content-type.
  await sandbox.handleResponseBodyCapture({
    url: "https://cdn.example.com/logo.png",
    contentType: "image/png",
    body: "binary-ish",
  });

  const state = dump();
  assert.equal(state["req-1-response-body"], '{"ok":true}');
  assert.equal(state["https://cdn.example.com/logo.png-response-body"], undefined);
});

test("handleResponseBodyCapture only fills in -size from the body's byte length when onHeadersReceived didn't already get one from Content-Length", async () => {
  const { sandbox, dump } = buildBackgroundSandbox();

  // Content-Length was already known (onHeadersReceived ran first, the
  // normal order) — the fallback must not clobber it, even though the
  // header value and the actual body length disagree here on purpose.
  sandbox.registerPendingBodyMatch("https://api.example.com/known-size", "req-1");
  await sandbox.chrome.storage.local.set({ "req-1-size": 999 });
  await sandbox.handleResponseBodyCapture({
    url: "https://api.example.com/known-size",
    body: "short",
  });

  // No Content-Length was ever recorded — falls back to the UTF-8 byte
  // length of the captured body (not the JS string length, which would be
  // wrong for multi-byte characters).
  sandbox.registerPendingBodyMatch("https://api.example.com/unknown-size", "req-2");
  await sandbox.handleResponseBodyCapture({
    url: "https://api.example.com/unknown-size",
    body: "é",
  });

  const state = dump();
  assert.equal(state["req-1-size"], 999);
  assert.equal(state["req-2-size"], 2);
});

test("isTrackableRequest rejects CORS preflight OPTIONS requests but keeps other XHR/fetch methods", () => {
  const { sandbox } = buildBackgroundSandbox();
  assert.equal(
    sandbox.isTrackableRequest({ type: "xmlhttprequest", method: "OPTIONS" }),
    false
  );
  assert.equal(
    sandbox.isTrackableRequest({ type: "xmlhttprequest", method: "GET" }),
    true
  );
  assert.equal(
    sandbox.isTrackableRequest({ type: "xmlhttprequest", method: "DELETE" }),
    true
  );
  assert.equal(
    sandbox.isTrackableRequest({ type: "image", method: "GET" }),
    false
  );
});

test("buildCurlCommandBase: GET has no --request flag (curl's own default)", () => {
  const { sandbox } = buildBackgroundSandbox();
  assert.equal(
    sandbox.buildCurlCommandBase("GET", "https://api.example.com/x"),
    "curl 'https://api.example.com/x'"
  );
});

test("buildCurlCommandBase: DELETE/PATCH/POST all get an explicit --request (regression: used to silently run as GET when executed)", () => {
  const { sandbox } = buildBackgroundSandbox();
  assert.equal(
    sandbox.buildCurlCommandBase("DELETE", "https://api.example.com/x"),
    "curl --request DELETE 'https://api.example.com/x'"
  );
  assert.equal(
    sandbox.buildCurlCommandBase("PATCH", "https://api.example.com/x"),
    "curl --request PATCH 'https://api.example.com/x'"
  );
  assert.equal(
    sandbox.buildCurlCommandBase("POST", "https://api.example.com/x"),
    "curl --request POST 'https://api.example.com/x'"
  );
});

test("updateBadgeCount counts every tab's requests by default (All tabs on)", async () => {
  const { sandbox, dump, badgeText } = buildBackgroundSandbox();

  await sandbox.chrome.storage.local.set({
    "req-1": "200 GET||application/json",
    "req-1-tab-id": 10,
    "req-2": "200 GET||application/json",
    "req-2-tab-id": 20,
    [sandbox.REQUEST_ORDER_KEY]: ["req-1", "req-2"],
  });

  await sandbox.updateBadgeCount();

  assert.equal(badgeText(), "2");
});

test("updateBadgeCount only counts the active tab's requests when 'All tabs' is off (regression: badge used to always show the global count, disagreeing with what the popup showed)", async () => {
  const { sandbox, setActiveTab, badgeText } = buildBackgroundSandbox();

  await sandbox.chrome.storage.local.set({
    "req-1": "200 GET||application/json",
    "req-1-tab-id": 10,
    "req-2": "200 GET||application/json",
    "req-2-tab-id": 20,
    [sandbox.REQUEST_ORDER_KEY]: ["req-1", "req-2"],
    [sandbox.SHOW_ALL_TABS_KEY]: false,
  });
  setActiveTab({ id: 10 });

  await sandbox.updateBadgeCount();

  assert.equal(badgeText(), "1");
});

test("clearTabRequests removes only the requests belonging to the given tab", async () => {
  const { sandbox, dump } = buildBackgroundSandbox();

  await sandbox.chrome.storage.local.set({
    "req-1-tab-id": 10,
    "req-1-url": "https://a.example.com",
  });
  await sandbox.trackAndEvict("req-1");

  await sandbox.chrome.storage.local.set({
    "req-2-tab-id": 20,
    "req-2-url": "https://b.example.com",
  });
  await sandbox.trackAndEvict("req-2");

  await sandbox.clearTabRequests(10);

  const state = dump();
  assert.equal(state["req-1-url"], undefined);
  assert.equal(state["req-2-url"], "https://b.example.com");
  const order = state[sandbox.REQUEST_ORDER_KEY];
  assert.equal(order.length, 1);
  assert.equal(order[0], "req-2");
});

test("clearAllRequests removes every tracked request and resets the badge", async () => {
  const { sandbox, dump, badgeText } = buildBackgroundSandbox();

  await sandbox.chrome.storage.local.set({
    "req-1-tab-id": 10,
    "req-1-url": "https://a.example.com",
  });
  await sandbox.trackAndEvict("req-1");

  await sandbox.clearAllRequests();

  const state = dump();
  assert.equal(state["req-1-url"], undefined);
  assert.equal(state[sandbox.REQUEST_ORDER_KEY], undefined);
  assert.equal(badgeText(), "");
});

test("networkErrorLabel: ERR_ABORTED reads as Canceled, everything else as Failed", () => {
  const { sandbox } = buildBackgroundSandbox();
  assert.equal(sandbox.networkErrorLabel("net::ERR_ABORTED"), "Canceled");
  assert.equal(
    sandbox.networkErrorLabel("net::ERR_CONNECTION_REFUSED"),
    "Failed"
  );
  assert.equal(sandbox.networkErrorLabel("net::ERR_FAILED"), "Failed");
});

test("handleRequestError writes a Failed/Canceled row (with the raw error preserved), computes its duration, and counts it in the badge, instead of the request just vanishing", async () => {
  const { sandbox, dump, badgeText } = buildBackgroundSandbox();

  await sandbox.chrome.storage.local.set({
    "req-1-pending": "GET",
    "req-1-start-time": 1000,
  });
  await sandbox.trackAndEvict("req-1");
  await sandbox.handleRequestError({
    requestId: "req-1",
    type: "xmlhttprequest",
    method: "GET",
    error: "net::ERR_CONNECTION_REFUSED",
    timeStamp: 1250,
  });

  const state = dump();
  assert.equal(state["req-1-pending"], undefined);
  assert.equal(
    state["req-1"],
    "Failed GET|||net::ERR_CONNECTION_REFUSED"
  );
  assert.equal(state["req-1-duration"], 250);
  assert.equal(badgeText(), "1");
});

test("computeDuration reads back the stashed start-time and rounds the delta; null when no start-time was ever recorded", async () => {
  const { sandbox } = buildBackgroundSandbox();

  await sandbox.chrome.storage.local.set({ "req-1-start-time": 1000 });
  assert.equal(await sandbox.computeDuration("req-1", 1300), 300);
  assert.equal(await sandbox.computeDuration("req-missing", 5000), null);
});

test("handleRequestError ignores non-trackable requests, same as the other webRequest listeners", async () => {
  const { sandbox, dump } = buildBackgroundSandbox();

  await sandbox.handleRequestError({
    requestId: "req-2",
    type: "image",
    method: "GET",
    error: "net::ERR_FAILED",
  });

  assert.equal(dump()["req-2"], undefined);
});
