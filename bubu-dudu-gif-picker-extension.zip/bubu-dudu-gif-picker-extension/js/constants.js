GIF_SIZE = "gif_size"
GIF_POSITION = "gif_position"
GIF_ANIMATION = "gif_animation"
GIF_DURATION = "gif_duration"
LIST_GIFS = "list_gifs"
GIF_SELECTED = "gif_selected"
IS_INIT = "is_init"
DISABLED_HOSTS = "disabled_hosts"
ENABLED_HOSTS = "enabled_hosts"
SITE_MODE = "site_mode"
RANDOM_MODE = "random_mode"
MULTI_GIF_MODE = "multi_gif_mode"
GIF_NAMES = "gif_names"
FAVORITE_GIFS = "favorite_gifs"
PRESETS = "presets"

TOP = "top"
BOTTOM = "bottom"
LEFT = "left"
RIGHT = "right"

SUCCESS_ALERT = "success-alert"
ERROR_ALERT = "error-alert"

GIF_SIZE_MIN = 20
GIF_SIZE_MAX = 600
GIF_SIZE_DEFAULT = 100

GIF_DURATION_MIN = 5
GIF_DURATION_MAX = 300
GIF_DURATION_DEFAULT = 60

MAX_GIF_FILE_SIZE_BYTES = 3 * 1024 * 1024

LIST_GIFS_DEFAULT = [
    "https://media.tenor.com/E-OQudBhX7UAAAAj/bubu-running-gif.gif",
    "https://media.tenor.com/kNS-PDTdtwYAAAAj/bubu-bike-running.gif",
    "https://media.tenor.com/tJfWFHTsEpUAAAAj/bubu-bubu-dudu.gif",
    "https://i.pinimg.com/originals/45/a7/e4/45a7e46bd4304e90342bbb8f5a39da53.gif",
    "https://media.tenor.com/ONCIbEgWKBoAAAAj/dudu-bubu-duck-dudu-running.gif",
    "https://media.tenor.com/B-FpLsTM7icAAAAj/dudu-run-dudu-bubu.gif",
    "https://media.tenor.com/A4TXiV6X-qEAAAAj/dudu-scare-dudu-running.gif",
    "https://media.tenor.com/0Xv7OG6CoL8AAAAj/bubu-dudu-bubu-dudu-angry.gif",
    "https://media.tenor.com/XQQ4sYyx9dkAAAAj/bubu-running-bubu-run.gif",
    "https://media.tenor.com/kaLAQMEWlHAAAAAj/bubu-car-bubu-running.gif",
    "https://media.tenor.com/0iEqC8aGXSAAAAAj/bubu-running-cute.gif",
    "https://media.tenor.com/Snvx1C6X1rAAAAAj/dudu-hut-bubu-dudu.gif",
    "https://media.tenor.com/6qTdop1aXoYAAAAj/bubu-driving-bubu-dudu.gif",
    "https://media.tenor.com/a4psORnW3vIAAAAj/bubu-dudu-sseeyall.gif",
    "https://media.tenor.com/dald7voqmC4AAAAj/bubu-dudu-sseeyall.gif",
    "https://media.tenor.com/lMOhstL51KEAAAAj/bubu-dudu-sseeyall.gif",
    "https://media.tenor.com/vLKIu2aX88kAAAAj/dudu-bubu-walking-to-school-cute.gif",
    "https://media.tenor.com/kxKRmJmW1RQAAAAj/tkthao219-bubududu.gif",
    "https://media.tenor.com/8xeZU73ldxcAAAAj/bubu-dudu-dudu-bubu.gif",
    "https://media.tenor.com/0JWcKoeZ3kkAAAAj/bubu-bubu-dudu.gif",
    "https://media.tenor.com/3MeBy_APrKYAAAAj/dudu-car-dudu-running.gif",
    "https://i.pinimg.com/originals/52/dc/ef/52dcef5db886e2b1e1a9eef0736c5722.gif",
    "https://media.tenor.com/XqezevYcHvMAAAAj/bubududu-drive.gif",
    "https://media.tenor.com/zTRWxZ91-sYAAAAj/bubu-dudu-bubu-dudu-angry.gif"
]

const BACKGROUND_SCREEN = "background"
const POPUP_SCREEN = "popup"

const HANDLE_MAIN_WEBSITE_LOADED = "main-website-loaded"
const HANDLE_SET_GIF_SIZE = "handle-set-gif-size";
const HANDLE_SET_GIF_POSITION = "handle-set-gif-position"
const HANDLE_SET_GIF_ANIMATION = "handle-set-gif-animation"
const HANDLE_SET_GIF_DURATION = "handle-set-gif-duration"
const HANDLE_SET_GIF_SELECTED = "handle-set-gif-selected"
const HANDLE_SET_DISABLED_HOSTS = "handle-set-disabled-hosts"
const HANDLE_SET_RANDOM_MODE = "handle-set-random-mode"
const HANDLE_CLEAR_GIF_SELECTED = "handle-clear-gif-selected"
const HANDLE_SETTINGS_IMPORTED = "handle-settings-imported"

const ADD_GIF_MENU_ID = "bubu-dudu-add-image-as-gif"
