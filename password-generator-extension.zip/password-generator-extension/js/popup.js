import {
    generatePasswordFromOptions,
    generatePassphraseFromOptions,
    estimatePasswordStrength,
    estimatePassphraseBits,
    pickRandomWord,
    pickRandomPassphraseNumber,
    assemblePassphrase
} from "./core.js";

const passwordField = document.getElementById("password");
const copyBtn = document.getElementById("copy");
const form = document.getElementById("generator-form");
const strengthMeter = document.getElementById("strength-meter");
const strengthBar = document.getElementById("strength-bar");
const strengthLabel = document.getElementById("strength-label");
const warningText = document.getElementById("warning-text");
const checkHint = document.getElementById("check-hint");

const modeField = document.getElementById("mode");
const segments = document.querySelectorAll(".segment");
const passwordOptions = document.getElementById("password-options");
const passphraseOptions = document.getElementById("passphrase-options");
const generalOptions = document.getElementById("general-options");
const generateBtn = document.getElementById("generate");
const chipRow = document.getElementById("passphrase-chips");

const lengthInput = document.getElementById("length");
const lengthRange = document.getElementById("length-range");
const lengthValue = document.getElementById("length-value");

const wordsRange = document.getElementById("passphrase-words");
const wordsValue = document.getElementById("words-value");

const customExcludeInput = document.getElementById("custom-exclude");

const historyCard = document.getElementById("history-card");
const historyList = document.getElementById("history-list");
const clearHistoryBtn = document.getElementById("clear-history");
const persistHistoryCheckbox = document.getElementById("persist-history");
const autoCopyCheckbox = document.getElementById("auto-copy");

const SETTINGS_STORAGE_KEY = "passwordGeneratorSettings";
const HISTORY_STORAGE_KEY = "passwordGeneratorHistory";
const SETTINGS_FIELD_IDS = [
    "mode",
    "length",
    "include-lower",
    "include-upper",
    "include-number",
    "include-symbol",
    "include-other",
    "exclude-duplicates",
    "exclude-ambiguous",
    "avoid-sequential",
    "custom-exclude",
    "passphrase-words",
    "passphrase-separator",
    "passphrase-capitalize",
    "passphrase-number",
    "auto-copy",
    "persist-history"
];

const STRENGTH_LEVELS = [
    { minBits: 70, label: "Strong", color: "#34c759", percent: 100 },
    { minBits: 40, label: "Medium", color: "#ff9f0a", percent: 60 },
    { minBits: 0, label: "Weak", color: "#ff3b30", percent: 30 }
];

const HISTORY_MAX = 5;
const historyEntries = [];

const storageAvailable = typeof chrome !== "undefined" && !!chrome.storage && !!chrome.storage.sync;
const historyStorageAvailable = typeof chrome !== "undefined" && !!chrome.storage && !!chrome.storage.local;

// Passphrase state, kept in sync with the chips so individual words/number can be rerolled.
let currentPassphrase = null; // { words: string[], number: string|null, separator: string }

/* ---------- Settings persistence ---------- */

function loadSettings() {
    if (!storageAvailable) {
        syncModeUI();
        syncSliderLabels();
        loadHistoryThenGenerate();
        return;
    }
    chrome.storage.sync.get(SETTINGS_STORAGE_KEY, (data) => {
        const settings = data[SETTINGS_STORAGE_KEY];
        if (settings) {
            SETTINGS_FIELD_IDS.forEach((id) => {
                const field = document.getElementById(id);
                if (!field || !(id in settings)) return;
                if (field.type === "checkbox") {
                    field.checked = settings[id];
                } else {
                    field.value = settings[id];
                }
            });
        }
        // "Check" is a session-only tool, not something to reopen the popup into.
        if (modeField.value === "check") modeField.value = "password";
        syncModeUI();
        syncSliderLabels();
        loadHistoryThenGenerate();
    });
}

function saveSettings() {
    if (!storageAvailable) return;
    const settings = {};
    SETTINGS_FIELD_IDS.forEach((id) => {
        const field = document.getElementById(id);
        if (!field) return;
        settings[id] = field.type === "checkbox" ? field.checked : field.value;
    });
    chrome.storage.sync.set({ [SETTINGS_STORAGE_KEY]: settings });
}

/* ---------- UI sync helpers ---------- */

function normalizeMode(value) {
    return value === "passphrase" || value === "check" ? value : "password";
}

function syncModeUI() {
    const mode = normalizeMode(modeField.value);
    segments.forEach((btn) => {
        const isActive = btn.dataset.mode === mode;
        btn.classList.toggle("active", isActive);
        btn.setAttribute("aria-selected", String(isActive));
    });
    passwordOptions.hidden = mode !== "password";
    passphraseOptions.hidden = mode !== "passphrase";
    generalOptions.hidden = mode === "check";
    generateBtn.hidden = mode === "check";
    checkHint.hidden = mode !== "check";
    passwordField.readOnly = mode !== "check";
    passwordField.placeholder = mode === "check" ? "Paste or type a password to check" : "";
    if (mode !== "passphrase") chipRow.hidden = true;
}

function syncSliderLabels() {
    lengthRange.value = lengthInput.value;
    lengthValue.textContent = lengthInput.value;
    wordsValue.textContent = wordsRange.value;
}

function showWarning(message) {
    warningText.textContent = message || "Select at least 1 character type";
    warningText.hidden = false;
    strengthMeter.style.visibility = "hidden";
    strengthLabel.style.visibility = "hidden";
    passwordField.value = "";
}

// Keep the Length slider/number/badge in sync with what was actually generated —
// the requested length can shrink (clamped to 6-64, or further clamped when
// "Exclude duplicates" can't fill the requested length from the available pool).
function syncLengthDisplay(actualLength) {
    lengthInput.value = actualLength;
    lengthRange.value = actualLength;
    lengthValue.textContent = actualLength;
}

function hideWarning() {
    warningText.hidden = true;
    strengthMeter.style.visibility = "visible";
    strengthLabel.style.visibility = "visible";
}

function renderStrengthFromBits(bits) {
    const level = STRENGTH_LEVELS.find((l) => bits >= l.minBits);
    strengthBar.style.width = `${level.percent}%`;
    strengthBar.style.background = level.color;
    strengthLabel.textContent = level.label;
}

function animateField() {
    passwordField.classList.remove("fade-in");
    void passwordField.offsetWidth;
    passwordField.classList.add("fade-in");
}

/* ---------- History ---------- */

function isPersistHistoryEnabled() {
    return !!(persistHistoryCheckbox && persistHistoryCheckbox.checked);
}

function persistHistory() {
    if (!historyStorageAvailable || !isPersistHistoryEnabled()) return;
    chrome.storage.local.set({ [HISTORY_STORAGE_KEY]: historyEntries });
}

function clearPersistedHistory() {
    if (!historyStorageAvailable) return;
    chrome.storage.local.remove(HISTORY_STORAGE_KEY);
}

function loadHistoryThenGenerate() {
    if (historyStorageAvailable && isPersistHistoryEnabled()) {
        chrome.storage.local.get(HISTORY_STORAGE_KEY, (data) => {
            const saved = data[HISTORY_STORAGE_KEY];
            if (Array.isArray(saved)) {
                historyEntries.push(...saved.slice(0, HISTORY_MAX));
                renderHistory();
            }
            generate();
        });
    } else {
        generate();
    }
}

function addToHistory(value) {
    if (!value) return;
    historyEntries.unshift(value);
    if (historyEntries.length > HISTORY_MAX) historyEntries.pop();
    renderHistory();
    persistHistory();
}

function renderHistory() {
    if (historyEntries.length === 0) {
        historyCard.hidden = true;
        return;
    }
    historyCard.hidden = false;
    historyList.innerHTML = "";
    historyEntries.forEach((value) => {
        const item = document.createElement("button");
        item.type = "button";
        item.className = "history-item";
        item.textContent = value;
        item.title = "Click to copy";
        item.addEventListener("click", () => {
            navigator.clipboard.writeText(value).then(() => {
                item.classList.add("copied");
                setTimeout(() => item.classList.remove("copied"), 600);
            });
        });
        historyList.appendChild(item);
    });
}

/* ---------- Copy ---------- */

function copyToClipboard(value) {
    if (!value) return;
    navigator.clipboard.writeText(value).then(() => {
        copyBtn.textContent = "✅";
        setTimeout(() => (copyBtn.textContent = "📋"), 1000);
    });
}

/* ---------- Passphrase word/number chips ---------- */

function renderChips() {
    if (!currentPassphrase) {
        chipRow.hidden = true;
        return;
    }
    chipRow.hidden = false;
    chipRow.innerHTML = "";
    currentPassphrase.words.forEach((word, index) => {
        const chip = document.createElement("button");
        chip.type = "button";
        chip.className = "chip";
        chip.textContent = word;
        chip.title = "Click to reroll this word";
        chip.addEventListener("click", () => rerollWord(index));
        chipRow.appendChild(chip);
    });
    if (currentPassphrase.number !== null) {
        const chip = document.createElement("button");
        chip.type = "button";
        chip.className = "chip";
        chip.textContent = currentPassphrase.number;
        chip.title = "Click to reroll this number";
        chip.addEventListener("click", rerollNumber);
        chipRow.appendChild(chip);
    }
}

function applyPassphraseUpdate() {
    const value = assemblePassphrase(currentPassphrase.words, currentPassphrase.number, currentPassphrase.separator);
    const bits = estimatePassphraseBits(currentPassphrase.words.length, currentPassphrase.number !== null);
    renderChips();
    applyGeneratedResult({ value, bits });
}

function rerollWord(index) {
    const capitalize = document.getElementById("passphrase-capitalize").checked;
    currentPassphrase.words[index] = pickRandomWord(capitalize);
    applyPassphraseUpdate();
}

function rerollNumber() {
    currentPassphrase.number = pickRandomPassphraseNumber();
    applyPassphraseUpdate();
}

/* ---------- Check mode ---------- */

function evaluateCheckMode() {
    chipRow.hidden = true;
    hideWarning();
    const value = passwordField.value;
    if (!value) {
        strengthBar.style.width = "0%";
        strengthLabel.textContent = "";
        return;
    }
    renderStrengthFromBits(estimatePasswordStrength(value).bits);
}

/* ---------- Dispatch ---------- */

function applyGeneratedResult(result) {
    hideWarning();
    passwordField.value = result.value;
    renderStrengthFromBits(result.bits);
    addToHistory(result.value);
    animateField();

    if (autoCopyCheckbox && autoCopyCheckbox.checked) {
        copyToClipboard(result.value);
    }
}

// Guards against a field's own change/input handler and the form's implicit
// submit-on-Enter both firing generate() for the same keystroke.
let lastGenerateAt = 0;
function generate() {
    const now = Date.now();
    if (now - lastGenerateAt < 100) return;
    lastGenerateAt = now;

    saveSettings();

    const mode = normalizeMode(modeField.value);

    if (mode === "check") {
        evaluateCheckMode();
        return;
    }

    if (mode === "passphrase") {
        const separator = document.getElementById("passphrase-separator").value;
        const result = generatePassphraseFromOptions({
            wordCount: wordsRange.value,
            separator,
            capitalize: document.getElementById("passphrase-capitalize").checked,
            includeNumber: document.getElementById("passphrase-number").checked
        });
        currentPassphrase = { words: result.words, number: result.number, separator };
        renderChips();
        applyGeneratedResult(result);
        return;
    }

    currentPassphrase = null;
    chipRow.hidden = true;
    const anyTypeSelected = ["include-lower", "include-upper", "include-number", "include-symbol", "include-other"]
        .some((id) => document.getElementById(id).checked);
    const result = generatePasswordFromOptions({
        length: lengthInput.value,
        includeLower: document.getElementById("include-lower").checked,
        includeUpper: document.getElementById("include-upper").checked,
        includeNumber: document.getElementById("include-number").checked,
        includeSymbol: document.getElementById("include-symbol").checked,
        includeOther: document.getElementById("include-other").checked,
        excludeDuplicates: document.getElementById("exclude-duplicates").checked,
        excludeAmbiguous: document.getElementById("exclude-ambiguous").checked,
        avoidSequential: document.getElementById("avoid-sequential").checked,
        customExclude: customExcludeInput.value
    });

    if (result.error) {
        showWarning(anyTypeSelected
            ? "No characters left — your exclusions removed every character in the selected types"
            : "Select at least 1 character type");
        return;
    }

    syncLengthDisplay(result.value.length);
    applyGeneratedResult(result);
}

/* ---------- Event wiring ---------- */

loadSettings();

form.addEventListener("submit", (e) => {
    e.preventDefault();
    generate();
});

copyBtn.addEventListener("click", () => {
    copyToClipboard(passwordField.value);
});

// In Password/Passphrase mode the field is read-only and only exists to be
// copied — auto-select its contents so a manual Cmd/Ctrl+C works immediately.
// Skipped in Check mode, where the field is a live input the user is editing.
passwordField.addEventListener("focus", () => {
    if (passwordField.readOnly) passwordField.select();
});

clearHistoryBtn.addEventListener("click", () => {
    historyEntries.length = 0;
    renderHistory();
    clearPersistedHistory();
});

persistHistoryCheckbox.addEventListener("change", () => {
    saveSettings();
    if (persistHistoryCheckbox.checked) {
        persistHistory();
    } else {
        clearPersistedHistory();
    }
});

segments.forEach((btn) => {
    btn.addEventListener("click", () => {
        modeField.value = btn.dataset.mode;
        syncModeUI();
        generate();
    });
});

let checkDebounce;
passwordField.addEventListener("input", () => {
    if (normalizeMode(modeField.value) !== "check") return;
    clearTimeout(checkDebounce);
    checkDebounce = setTimeout(generate, 150);
});

lengthInput.addEventListener("input", () => {
    lengthRange.value = lengthInput.value;
    lengthValue.textContent = lengthInput.value;
});
lengthInput.addEventListener("change", generate);

let lengthRangeDebounce;
lengthRange.addEventListener("input", () => {
    lengthInput.value = lengthRange.value;
    lengthValue.textContent = lengthRange.value;
    clearTimeout(lengthRangeDebounce);
    lengthRangeDebounce = setTimeout(generate, 120);
});

let wordsRangeDebounce;
wordsRange.addEventListener("input", () => {
    wordsValue.textContent = wordsRange.value;
    clearTimeout(wordsRangeDebounce);
    wordsRangeDebounce = setTimeout(generate, 120);
});

let excludeDebounce;
customExcludeInput.addEventListener("input", () => {
    clearTimeout(excludeDebounce);
    excludeDebounce = setTimeout(generate, 300);
});

[
    "include-lower",
    "include-upper",
    "include-number",
    "include-symbol",
    "include-other",
    "exclude-duplicates",
    "exclude-ambiguous",
    "avoid-sequential",
    "passphrase-separator",
    "passphrase-capitalize",
    "passphrase-number",
    "auto-copy"
].forEach((id) => {
    document.getElementById(id).addEventListener("change", generate);
});
